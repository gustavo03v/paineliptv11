<?php
header("Access-Control-Allow-Origin: *"); 
date_default_timezone_set('America/Sao_Paulo');
header("Server: nginx");

function conectar_bd() {
    $endereco = getenv('DB_HOST') ?: 'localhost';
    $banco = getenv('DB_NAME') ?: 'xtserveropensource';
    $dbusuario = getenv('DB_USER') ?: 'root';
    $dbsenha = getenv('DB_PASS') ?: '032530';

    try {
        $conexao = new PDO("mysql:host=$endereco;dbname=$banco", $dbusuario, $dbsenha);
        $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conexao;
    } catch(PDOException $e) {
        error_log('Erro na conexao com o banco de dados: ' . $e->getMessage());
        return null;
    }
}
?>